import Database from 'better-sqlite3';

const db = new Database('./tickets.db');

db.exec(`
CREATE TABLE IF NOT EXISTS tickets (
  id TEXT PRIMARY KEY,
  buyer_name TEXT,
  buyer_email TEXT,
  buyer_phone TEXT,
  function_id TEXT,
  function_label TEXT,
  price INTEGER,
  currency TEXT,
  status TEXT DEFAULT 'valid',
  created_at TEXT DEFAULT (datetime('now')),
  used_at TEXT
);

CREATE TABLE IF NOT EXISTS payments (
  id TEXT PRIMARY KEY,
  mp_payment_id TEXT,
  preference_id TEXT,
  status TEXT,
  buyer_email TEXT,
  raw_json TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);
`);

export default db;
