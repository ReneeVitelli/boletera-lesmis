import mercadopago from 'mercadopago';

export function initMP() {
  const { MP_ACCESS_TOKEN } = process.env;
  mercadopago.configure({ access_token: MP_ACCESS_TOKEN });
  return mercadopago;
}

export async function createPreference({ title, quantity, price, currency, backUrls, metadata }) {
  const mp = initMP();
  const preference = {
    items: [{ title, quantity, currency_id: currency, unit_price: Number(price) }],
    back_urls: backUrls,
    auto_return: 'approved',
    metadata
  };
  const res = await mp.preferences.create(preference);
  return res.body;
}

export async function getPayment(paymentId) {
  const mp = initMP();
  const res = await mp.payment.findById(paymentId);
  return res.body;
}
