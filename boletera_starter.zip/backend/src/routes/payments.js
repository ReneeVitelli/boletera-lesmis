import { Router } from 'express';
import { createPreference, getPayment } from '../mercadoPago.js';
import db from '../db.js';
import fetch from 'node-fetch';

const router = Router();

// Crear preferencia de pago (desde el frontend)
router.post('/preference', async (req, res) => {
  try {
    const { title, quantity, price, currency, success_url, failure_url, pending_url, metadata } = req.body;
    const pref = await createPreference({
      title,
      quantity,
      price,
      currency,
      backUrls: {
        success: success_url,
        failure: failure_url || success_url,
        pending: pending_url || success_url
      },
      metadata
    });
    res.json({ ok: true, preference: pref });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok: false, error: e.message });
  }
});

// Webhook de Mercado Pago
router.post('/webhook', async (req, res) => {
  try {
    // MP envía eventos; aquí hacemos una lectura flexible
    const type = req.query.type || req.body.type;
    const dataId = req.query['data.id'] || req.body?.data?.id;

    if (type === 'payment' || (req.body && req.body.type === 'payment')) {
      const paymentId = dataId || req.body.data?.id;
      if (!paymentId) return res.sendStatus(200);

      const payment = await getPayment(paymentId);
      const status = payment.status;

      // Guarda el pago
      db.prepare('INSERT OR REPLACE INTO payments (id, mp_payment_id, status, buyer_email, raw_json) VALUES (?, ?, ?, ?, ?)')
        .run(String(payment.id), String(payment.id), status, payment.payer?.email || null, JSON.stringify(payment));

      // Si aprobado, emitir boletos
      if (status === 'approved') {
        const buyer_name = payment.additional_info?.payer?.first_name || '';
        const buyer_email = payment.payer?.email || null;
        const quantity = payment.additional_info?.items?.[0]?.quantity || 1;
        const title = payment.additional_info?.items?.[0]?.title || process.env.EVENT_TITLE;
        const price = Math.round(payment.transaction_amount || process.env.PRICE_GENERAL);
        const currency = payment.currency_id || process.env.CURRENCY || 'MXN';
        const function_id = payment.metadata?.function_id || 'funcion-1';
        const function_label = payment.metadata?.function_label || title;

        // Emite
        const resp = await fetch(`${process.env.BASE_URL}/api/tickets/issue`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ buyer_name, buyer_email, function_id, function_label, quantity, price, currency, event_title: title })
        });
        await resp.json();
      }
    }

    res.sendStatus(200);
  } catch (e) {
    console.error(e);
    res.sendStatus(200);
  }
});

export default router;
